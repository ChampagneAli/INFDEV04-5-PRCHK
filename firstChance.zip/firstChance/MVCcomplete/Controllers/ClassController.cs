using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Model;

namespace reac_mvc_movie_app.Controllers
{
    [Route("[controller]")]
    public class ClassController : Controller
    {
        private readonly SchoolContext _context;

        public ClassController(SchoolContext context)
        {
            _context = context;
            
            if(context.Classes.Count() == 0 && context.Students.Count() == 0){
                var class1 = new Class(){
                    Code = "01H1",
                    Year = "2017-2018",
                    Students = new List<Student>(){
                        new Student(){Name = "Brad Pit", Birth=DateTime.Now, Gender="Male"},
                        new Student(){Name = "Tom Hanks", Birth=DateTime.Now, Gender="Male"}
                    }
                };
                var class2 = new Class(){
                    Code = "02J1",
                    Year = "2018-2019",
                    Students = new List<Student>(){
                        new Student(){Name = "Michael Janson", Birth=DateTime.Now, Gender="Male"},
                        new Student(){Name = "Jim Thomson", Birth=DateTime.Now, Gender="Male"}
                    }
                };
                _context.Classes.Add(class1);
                _context.Classes.Add(class2);
                _context.SaveChanges();
            }

        }

        // TODO 5: Fill in the missing code 0.25 ptn

        public IActionResult GetAll(){
        // TODO 6: Fill in the missing code 0.5 ptn
     

          return Ok(_classes.ToArray());
        }

        // TODO 7: Fill in the missing code 0.25 ptn

        public IActionResult GetClass(int id){
          var _class = (from m in _context.Classes
                    // TODO 8: Fill in the missing code 0.25 ptn
                   
                       let students = _context.Students.Where(a => a.ClassId == m.Id).ToList()
                       select new Class(){Id=m.Id, Students = students, Code=m.Code, Year=m.Year}).FirstOrDefault();
                       
        // TODO 9: Fill in the missing code 0.5 ptn

          return Ok(_class);
        }
    }
}
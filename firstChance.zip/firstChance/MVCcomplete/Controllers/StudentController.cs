using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Model;

namespace reac_mvc_movie_app.Controllers
{
    [Route("[controller]")]
    public class StudentController : Controller
    {
        private readonly SchoolContext _context;

        public StudentController(SchoolContext context)
        {
            _context = context;
        }

        // TODO 10: Fill in the missing code 0.25 ptn

        public IActionResult GetAll(){
        // TODO 11: Fill in the missing code 0.25 ptn

        }

        // TODO 12: Fill in the missing code 0.25 ptn

        public IActionResult GetStudent(int id){
          var student = _context.Students.Where(a => a.Id == id).FirstOrDefault();
          
        // TODO 13: Fill in the missing code 0.5 ptn

          return Ok(student);
        }
    }
}
import * as React from 'react';
import { Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './components/Home';
import { FetchData } from './components/FetchData';
import { Counter } from './components/Counter';
import { ClassesManager } from './components/ClassesManager';
import { ClassRouter } from './components/Class';
import { StudentsManager } from './components/StudentsManager';
import { StudentRouter } from './components/Student';

export const routes = <Layout>
    <Route exact path='/' component={ Home } />
    <Route path='/counter' component={ Counter } />
    <Route path='/fetchdata' component={ FetchData } />
    <Route path='/classesmanager' component={ ClassesManager } />
    <Route path='/class/:id' component={ ClassRouter } />
    {/* // TODO 15: Fill in the missing code 0.5 ptn */}
   
    <Route path='/student/:id' component={ StudentRouter } />
</Layout>;

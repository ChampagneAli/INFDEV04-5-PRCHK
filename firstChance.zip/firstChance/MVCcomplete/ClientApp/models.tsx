export type Class = {
  id:number,
  code:string,
  year:string,
  students:Student[]
}

export type Student = {
  id:number,
  name:string,
  surname:string
  gener:string,
  birth:Date
}


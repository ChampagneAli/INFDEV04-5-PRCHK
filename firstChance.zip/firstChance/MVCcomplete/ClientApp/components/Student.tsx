import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import { Link, NavLink } from 'react-router-dom';
import * as Models from '../models'



async function getStudent(id:number) : Promise<Models.Student>{
  let responce = await fetch(`Student/GetStudent/${id}`, { method: 'get',  credentials: 'include', headers: { 'content-type': 'application/json' } })
  let res = responce.json()
  return res
}
export class StudentRouter extends React.Component<RouteComponentProps<{id:number}>, {student:Models.Student|"loading"}> {
  constructor(props:RouteComponentProps<{id:number}>){
    super(props)
    this.state = {student:"loading"}
  }
  componentWillMount(){
    getStudent(this.props.match.params.id)
      .then(loaded_student => this.setState({...this.state, student:loaded_student}))
      .catch(error => console.error("error while downloading the student", error))
  }
  // TODO 22: Fill in the missing code 0.25 ptn
 
}


type StudentProps = {student:Models.Student, preview:boolean}
export class Student extends React.Component<StudentProps, {}> {
    constructor(props:StudentProps){
      super(props)
      this.state = {}
    }

    public render() {
      if(this.props.preview){
        // TODO 23: Fill in the missing code 0.5 ptn
        
      }
      return <div>
          <div><h3>Student:</h3></div>
          <div> {this.props.student.name} </div>
        </div>
    }
}

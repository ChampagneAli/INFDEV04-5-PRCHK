import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import * as Models from '../models'
import {Student} from './Student'




async function getClass(id:number) : Promise<Models.Class>{
  let responce = await fetch(`Class/GetClass/${id}`, { method: 'get',  credentials: 'include', headers: { 'content-type': 'application/json' } })
  let res = responce.json()
  return res
}

// TODO 19: Fill in the missing code 0.5 ptn

  constructor(props:RouteComponentProps<{id:number}>){
    super(props)
    this.state = {class:"loading"}
  }
  componentWillMount(){
    getClass(this.props.match.params.id)
      .then(loaded_class => this.setState({...this.state, class:loaded_class}))
      .catch(error => console.error("error while downloading class", error))
  }
  // TODO 20: Fill in the missing code 0.25 ptn
  
}


type ClassProps = {class:Models.Class, preview:boolean}
export class Class extends React.Component<ClassProps, {}> {
    constructor(props:ClassProps){
      super(props)
      this.state = {}
    }


    public render() {
      if(this.props.preview){
        return <div style={{display:"inline"}}>
            {this.props.class.code}
          </div>
      }
      return <div>
          <div><h3>Class:</h3></div>
          <div> {this.props.class.code} </div>
          <div><h3>Students:</h3></div>
          <div>
            {this.props.class.students.map(s => 
              <div>
                <Student student={s} preview={true}/>
              </div>)}
          </div>
        </div>
    }
}

import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import { Link, NavLink } from 'react-router-dom';

import * as Models from '../models'
import {Class} from './Class'
import {Student} from './Student'
async function getAllClasses() : Promise<Models.Class[]>{
  // TODO 16: Fill in the missing code 0.5 ptn
 
  return res
}

// TODO 17: Fill in the missing code 0.5 ptn


export class ClassesManager extends React.Component<RouteComponentProps<{}>, ClassesManagerState> {
    constructor(props:RouteComponentProps<{}>){
      super(props)
      this.state = {classes:"loading"}
    }

    // TODO 18: Fill in the missing code 0.5 ptn
   
    
    public render() {
      if(this.state.classes == "loading") return <div>loading classes...</div>
      return <div>
          
            {this.state.classes.map(c => 
              <div>
                <div><h3>Class:</h3></div>
                <Class class={c} preview={true}/>
                <NavLink style={{display:"inline"}} to={ `/class/${c.id}` } exact activeClassName='active'>
                    <button>+</button>
                </NavLink>
                
                <div><h4>Students:</h4></div>
                {c.students.map(s => 
                  <div>
                    <Student student={s} preview={true}/>
                  </div>
                  )}
                <br/>
              </div>)}

        </div>
    }
}

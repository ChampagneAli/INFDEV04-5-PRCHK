import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import { Link, NavLink } from 'react-router-dom';

import * as Models from '../models'
import {Student} from './Student'
async function getAllStudents() : Promise<Models.Student[]>{
  let responce = await fetch(`Student/GetAll`, { method: 'get',  credentials: 'include', headers: { 'content-type': 'application/json' } })
  let res = responce.json()
  return res
}


type StudentsManagerState = { students:Models.Student[] | "loading" }

export class StudentsManager extends React.Component<RouteComponentProps<{}>, StudentsManagerState> {
    constructor(props:RouteComponentProps<{}>){
      super(props)
      this.state = {students:"loading"}
    }

    componentWillMount(){
        getAllStudents().then(loaded_students => {
                      this.setState({...this.state, students:loaded_students})
                    })
                    .catch(error => console.error("error while downloading all students", error))
    }

    public render() {
      if(this.state.students == "loading") return <div>loading students...</div>
      return <div>
            <div><h3>Students:</h3></div>
            // TODO 21: Fill in the missing code 1.0 ptn
           
        </div>
    }
}

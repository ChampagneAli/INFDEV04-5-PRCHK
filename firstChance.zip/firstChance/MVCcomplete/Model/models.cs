using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;


namespace Model{
  public class SchoolContext : DbContext {
        public DbSet<Class> Classes { get; set; }
        // TODO 1: Fill in the missing code 0.5 ptn


        public SchoolContext(DbContextOptions<SchoolContext> options)
            : base(options)
        { }
        
    }

    public class Class {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Year { get; set; }
        // TODO 2: Fill in the missing code 0.5 ptn

    }

    public class Student {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Birth { get; set; }
        public string Gender { get; set; }
        // TODO 3: Fill in the missing code 0.5 ptn
        
        

    }
}




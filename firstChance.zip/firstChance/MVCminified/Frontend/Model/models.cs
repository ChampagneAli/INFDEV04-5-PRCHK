using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;


namespace Model{
  public class SchoolContext : DbContext {
        public DbSet<Class> Classes { get; set; }
        public DbSet<Student> Students { get; set; }

        public SchoolContext(DbContextOptions<SchoolContext> options)
            : base(options)
        { }
        
    }

    public class Class {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Year { get; set; }
        public List<Student> Students { get; set; }
    }

    public class Student {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Birth { get; set; }
        public string Gender { get; set; }
        public int ClassId { get; set; }
        public Class Class { get; set; }

    }
}




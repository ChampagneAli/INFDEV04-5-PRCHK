using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Model;

namespace reac_mvc_movie_app.Controllers
{
    [Route("[controller]")]
    public class StudentController : Controller
    {
        private readonly SchoolContext _context;

        public StudentController(SchoolContext context)
        {
            _context = context;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll(){
          return Ok(_context.Students.ToArray());
        }

        [HttpGet("GetStudent/{id}")]
        public IActionResult GetActor(int id){
          var student = _context.Students.Where(a => a.Id == id).FirstOrDefault();
          if(student == null) return NotFound();
          return Ok(student);
        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Model;

namespace reac_mvc_movie_app.Controllers
{
    [Route("[controller]")]
    public class ClassController : Controller
    {
        private readonly SchoolContext _context;

        public ClassController(SchoolContext context)
        {
            _context = context;
            
            if(context.Classes.Count() == 0 && context.Students.Count() == 0){
                var class1 = new Class(){
                    Code = "01H1",
                    Year = "2017-2018",
                    Students = new List<Student>(){
                        new Student(){Name = "Brad Pit", Birth=DateTime.Now, Gender="Male"},
                        new Student(){Name = "Tom Hanks", Birth=DateTime.Now, Gender="Male"}
                    }
                };
                var class2 = new Class(){
                    Code = "02J1",
                    Year = "2018-2019",
                    Students = new List<Student>(){
                        new Student(){Name = "Michael Janson", Birth=DateTime.Now, Gender="Male"},
                        new Student(){Name = "Jim Thomson", Birth=DateTime.Now, Gender="Male"}
                    }
                };
                _context.Classes.Add(class1);
                _context.Classes.Add(class2);
                _context.SaveChanges();
            }

        }

        [HttpGet("GetAll")]
        public IActionResult GetAll(){
          var _classes = from m in _context.Classes
                       let students = _context.Students.Where(a => a.ClassId == m.Id).ToList()
                       select new Class(){Id=m.Id, Students = students, Code=m.Code, Year=m.Year};

          return Ok(_classes.ToArray());
        }

        [HttpGet("GetClass/{id}")]
        public IActionResult GetClass(int id){
          var _class = (from m in _context.Classes
                       where m.Id == id
                       let students = _context.Students.Where(a => a.ClassId == m.Id).ToList()
                       select new Class(){Id=m.Id, Students = students, Code=m.Code, Year=m.Year}).FirstOrDefault();

          if(_class == null) return NotFound();
          return Ok(_class);
        }
    }
}